const car = document.getElementById('car');
const gameArea = document.getElementById('game-area');
const background = document.createElement('div');
background.id = 'background';
gameArea.appendChild(background);

// ضبط موقع السيارة
let carPosition = {
    x: 175,
    y: 550,
};

function moveCar() {
    car.style.left = carPosition.x + 'px';
    car.style.bottom = carPosition.y + 'px';
    // تحريك الخلفية بشكل عكسي بناءً على حركة السيارة
    background.style.transform = `translateY(${(550 - carPosition.y) * 0.5}px)`;
}

document.getElementById('up').addEventListener('click', function() {
    if (carPosition.y < gameArea.clientHeight - 50) { // تأكد من عدم الخروج عن الشاشة
        carPosition.y += 10;
    }
    moveCar();
});

document.getElementById('down').addEventListener('click', function() {
    if (carPosition.y > 0) {
        carPosition.y -= 10;
    }
    moveCar();
});

document.getElementById('left').addEventListener('click', function() {
    if (carPosition.x > 0) {
        carPosition.x -= 10;
    }
    moveCar();
});

document.getElementById('right').addEventListener('click', function() {
    if (carPosition.x < gameArea.clientWidth - 50) { // تأكد من عدم الخروج عن الشاشة
        carPosition.x += 10;
    }
    moveCar();
});