const playButton = document.getElementById("playButton");
const gameScreen = document.getElementById("gameScreen");
const container = document.querySelector(".container");
const questionElement = document.getElementById("question");
const answersContainer = document.getElementById("answers");

const story = [
  {
    question: "رجل غريب يطرق بابك ويطلب المساعدة. ماذا تفعل؟",
    answers: ["- اذهب معه", "- لا أذهب معه"]
  },
  {
    question: "تسمع صوتًا غريبًا في الغابة ليلاً. هل تتحقق؟",
    answers: ["- أتحقق", "- أعود إلى المنزل"]
  },
  {
    question: "ترى بابًا مفتوحًا في قبو مظلم. هل تدخله؟",
    answers: ["- أدخل", "- لا أدخل"]
  }
];

let currentQuestionIndex = 0;

playButton.addEventListener("click", () => {
  fadeToBlack();
});

function fadeToBlack() {
  container.style.transition = "opacity 1s";
  container.style.opacity = 0;

  setTimeout(() => {
    container.style.display = "none";
    gameScreen.classList.remove("hidden");
    showQuestion();
  }, 1000);
}

function showQuestion() {
  const currentStoryPart = story[currentQuestionIndex];
  questionElement.textContent = "";
  answersContainer.innerHTML = "";

  // Simulate typing effect
  let i = 0;
  const typingInterval = setInterval(() => {
    if (i < currentStoryPart.question.length) {
      questionElement.textContent += currentStoryPart.question[i];
      i++;
    } else {
      clearInterval(typingInterval);

      // Show answers after typing
      currentStoryPart.answers.forEach(answer => {
        const answerElement = document.createElement("div");
        answerElement.textContent = answer;
        answerElement.className = "answer";
        answersContainer.appendChild(answerElement);

        answerElement.addEventListener("click", () => handleAnswer(answer));
      });
    }
  }, 50);
}

function handleAnswer(answer) {
  if (currentQuestionIndex < story.length - 1) {
    currentQuestionIndex++;
    showQuestion();
  } else {
    endGame();
  }
}

function endGame() {
  questionElement.textContent = "النهاية. شكراً للعب!";
  answersContainer.innerHTML = "";
}